# 🧠 Tetris Neural Network — Genetic Algorithm Trainer

Uma Rede Neural que aprende a jogar Tetris através de Algoritmo Genético,
com visualização do treinamento em tempo real.

---

## Como funciona

### Rede Neural
- **Arquitetura:** 8 entradas → 20 neurônios ocultos (tanh) → 1 saída (linear)
- **Total de pesos:** 181 parâmetros treináveis
- **Função:** Avalia a "qualidade" de um estado do tabuleiro e retorna uma pontuação

### Estratégia de Jogo (Busca Exaustiva de Jogadas)
Para cada peça que aparece, a IA:
1. Enumera **todas** as posições possíveis (rotação × coluna)
2. Simula cada colocação em uma cópia do tabuleiro
3. Extrai **8 features** do estado resultante
4. Passa as features pela Rede Neural → obtém um score
5. Executa a jogada com **maior score**

### Features do Tabuleiro (entradas da NN)
| # | Feature | Descrição |
|---|---------|-----------|
| 0 | Altura agregada | Soma das alturas de todas as colunas |
| 1 | Linhas completas | Número de linhas prontas para limpar |
| 2 | Buracos | Células vazias abaixo de células preenchidas |
| 3 | Irregularidade | Soma das diferenças de altura entre colunas adjacentes |
| 4 | Altura máxima | Altura da coluna mais alta |
| 5 | Altura mínima | Altura da coluna mais baixa |
| 6 | Poços | Depressões profundas entre colunas altas |
| 7 | Desvio padrão | Variação entre alturas das colunas |

### Algoritmo Genético
- **População:** 200 redes neurais por geração
- **Fitness:** `linhas_limpas × 1000 + peças_colocadas`
- **Elitismo:** Top 10 sobrevivem sem modificação
- **Seleção:** Torneio com k=7 candidatos
- **Cruzamento:** Crossover uniforme (cada peso vem aleatoriamente do pai A ou B)
- **Mutação:** Perturbação Gaussiana (σ=0.25) com probabilidade 12% por peso
- **Avaliação paralela:** Usa todos os núcleos da CPU

---

## Pré-requisitos

- **Java JDK 11+** (recomendado: JDK 17 ou 21)
- Verificar: `java -version` e `javac -version`

Download JDK: https://adoptium.net/

---

## Como executar

### Linux / macOS
```bash
chmod +x run.sh
./run.sh
```

### Windows
```
run.bat
```

### Manual
```bash
mkdir out
javac src/*.java -d out
java -cp out TetrisAI
```

---

## Interface

```
┌──────────────────────────────────────────────────┐
│  🧠 Tetris — Neural Network Learns to Play        │
├──────────────────────┬───────────────────────────┤
│                      │  Generation: 42            │
│   Demo em tempo real │  Best Lines: 318           │
│   (melhor agente     │  Best Fitness: 318,492      │
│    jogando)          │  Avg Fitness: 87,234        │
│                      │                            │
│   ██████████         │  [Gráfico de Fitness]       │
│   ██    ████         │                            │
│   ██████████         │  [Diagrama da NN]          │
│                      │                            │
│                      │  [Heatmap de Pesos W1]      │
├──────────────────────┴───────────────────────────┤
│  Demo Speed: [====------]  [⏸ Pause Training]    │
└──────────────────────────────────────────────────┘
```

### Controles
| Controle | Função |
|----------|--------|
| Slider "Demo Speed" | Ajusta a velocidade da animação do jogo ao vivo |
| ⏸ Pause Training | Pausa/retoma o treinamento genético |

---

## Estrutura de Arquivos

```
tetris-ai/
├── src/
│   ├── TetrisAI.java          ← Ponto de entrada
│   ├── NeuralNetwork.java     ← Rede Neural (8→20→1)
│   ├── SimBoard.java          ← Tabuleiro headless + extração de features
│   ├── TetrisSimulator.java   ← Motor de simulação + busca de jogadas
│   ├── GeneticAlgorithm.java  ← GA com avaliação multi-thread
│   ├── TrainingFrame.java     ← Janela principal
│   ├── TetrisDisplay.java     ← Painel do jogo ao vivo
│   ├── StatsPanel.java        ← Gráficos e estatísticas
│   │
│   │   ── Jogo original (modo humano) ──
│   ├── Board.java
│   ├── Tetromino.java
│   ├── GamePanel.java
│   └── Tetris.java            ← java -cp out Tetris  (jogar manualmente)
│
├── run.sh                     ← Build + run (Linux/macOS)
├── run.bat                    ← Build + run (Windows)
└── README.md
```

---

## Jogar manualmente
```bash
javac src/*.java -d out
java -cp out Tetris
```

---

## Convergência esperada

| Geração | Linhas (típico) | Comportamento |
|---------|-----------------|---------------|
| 1–5     | 0–10            | Joga aleatoriamente, morre rápido |
| 10–20   | 20–80           | Começa a evitar buracos |
| 30–50   | 100–300         | Estratégia de limpeza de linhas emerge |
| 100+    | 500–2000+       | Jogo consistente e eficiente |

O tempo por geração depende da CPU. Com 4 núcleos, espere ~2–5 segundos/geração.
