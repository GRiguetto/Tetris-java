import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

/**
 * Main application window for Tetris Neural Network training.
 *
 * Layout:
 *   ┌─────────────────────────────────┐
 *   │         Header / title          │
 *   ├──────────────┬──────────────────┤
 *   │ TetrisDisplay│   StatsPanel     │
 *   │ (live game)  │  (charts/stats)  │
 *   ├──────────────┴──────────────────┤
 *   │  Controls bar                   │
 *   └─────────────────────────────────┘
 */
public class TrainingFrame extends JFrame {

    // ── Shared training state (written by training thread, read by EDT) ──
    volatile NeuralNetwork bestNet      = null;
    volatile int           currentGen   = 0;
    volatile int           bestFitness  = 0;
    volatile int           bestLines    = 0;
    volatile double        avgFitness   = 0;

    final List<Integer> bestHistory = Collections.synchronizedList(new ArrayList<>());
    final List<Double>  avgHistory  = Collections.synchronizedList(new ArrayList<>());

    // ── Demo speed controls ──────────────────────────────────────────────
    private volatile int dropDelay = 60;   // ms between row-drops during animation
    private volatile int lockDelay = 80;   // ms after piece locks

    // ── UI components ────────────────────────────────────────────────────
    private TetrisDisplay tetrisDisplay;
    private StatsPanel    statsPanel;
    private JButton       pauseButton;
    private JLabel        statusLabel;
    private volatile boolean paused = false;
    private volatile boolean running = true;

    // ── Timer to refresh the stats panel ─────────────────────────────────
    private javax.swing.Timer refreshTimer;

    public TrainingFrame() {
        super("Tetris Neural Network — Genetic Algorithm Training");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(new Color(12, 12, 22));
        setLayout(new BorderLayout(0, 0));

        add(buildHeader(),   BorderLayout.NORTH);
        add(buildCenter(),   BorderLayout.CENTER);
        add(buildControls(), BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        // Refresh stats panel ~10 fps
        refreshTimer = new javax.swing.Timer(100, e -> {
            statsPanel.repaint();
            updateStatus();
        });
        refreshTimer.start();

        startTraining();
        tetrisDisplay.startDemo();
    }

    // ── Layout builders ──────────────────────────────────────────────────

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(18, 18, 32));
        p.setBorder(BorderFactory.createEmptyBorder(10, 14, 8, 14));

        JLabel title = new JLabel("🧠  Tetris — Neural Network Learns to Play");
        title.setFont(new Font("Monospaced", Font.BOLD, 17));
        title.setForeground(new Color(100, 190, 255));
        p.add(title, BorderLayout.WEST);

        statusLabel = new JLabel("Initialising…");
        statusLabel.setFont(new Font("Monospaced", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(100, 200, 100));
        p.add(statusLabel, BorderLayout.EAST);

        return p;
    }

    private JPanel buildCenter() {
        tetrisDisplay = new TetrisDisplay(this);
        statsPanel    = new StatsPanel(this);

        JPanel left = new JPanel(new BorderLayout());
        left.setBackground(new Color(12, 12, 22));
        left.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 5));

        JLabel lbl = new JLabel("Demo — Best Agent Playing", JLabel.CENTER);
        lbl.setFont(new Font("Monospaced", Font.BOLD, 12));
        lbl.setForeground(new Color(140, 140, 200));
        lbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 4, 0));
        left.add(lbl,          BorderLayout.NORTH);
        left.add(tetrisDisplay, BorderLayout.CENTER);

        JPanel right = new JPanel(new BorderLayout());
        right.setBackground(new Color(12, 12, 22));
        right.setBorder(BorderFactory.createEmptyBorder(8, 5, 8, 10));
        right.add(statsPanel, BorderLayout.CENTER);

        JPanel center = new JPanel(new GridLayout(1, 2, 0, 0));
        center.setBackground(new Color(12, 12, 22));
        center.add(left);
        center.add(right);
        return center;
    }

    private JPanel buildControls() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 7));
        p.setBackground(new Color(18, 18, 32));
        p.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(50, 50, 80)));

        // --- Demo Speed ---
        JLabel lbl1 = label("Demo Speed:");
        p.add(lbl1);

        JSlider speedSlider = new JSlider(1, 20, 10);
        speedSlider.setBackground(new Color(18, 18, 32));
        speedSlider.setForeground(Color.WHITE);
        speedSlider.setPreferredSize(new Dimension(130, 26));
        speedSlider.setToolTipText("Adjust animation speed of the live demo");
        speedSlider.addChangeListener(e -> {
            int v = speedSlider.getValue();          // 1 = slow, 20 = fast
            dropDelay = 200 / v;
            lockDelay = 160 / v;
        });
        p.add(speedSlider);

        // --- Pause / Resume ---
        pauseButton = new JButton("⏸  Pause Training");
        styleButton(pauseButton, new Color(70, 70, 110));
        pauseButton.addActionListener(e -> togglePause());
        p.add(pauseButton);

        // --- Separator ---
        p.add(Box.createHorizontalStrut(12));

        // --- Config labels ---
        p.add(label(String.format(
            "Pop: %d   Elite: %d   Mutation: %.0f%%   Architecture: %d→%d→%d",
            GeneticAlgorithm.POP_SIZE, GeneticAlgorithm.ELITE,
            GeneticAlgorithm.MUT_RATE * 100,
            NeuralNetwork.IN, NeuralNetwork.H1, NeuralNetwork.OUT)));

        return p;
    }

    // ── Training Thread ──────────────────────────────────────────────────

    private void startTraining() {
        GeneticAlgorithm ga = new GeneticAlgorithm();
        ga.addListener((gen, best, avg, lines, net) -> {
            currentGen  = gen;
            bestFitness = best;
            avgFitness  = avg;
            bestLines   = lines;
            bestNet     = net;
            bestHistory.add(best);
            avgHistory.add(avg);
        });

        Thread t = new Thread(() -> {
            while (running) {
                if (paused) {
                    sleep(200);
                } else {
                    try { ga.evolve(); }
                    catch (InterruptedException e) { break; }
                    catch (Exception e) { e.printStackTrace(); }
                }
            }
        }, "training-thread");
        t.setDaemon(true);
        t.start();
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    private void togglePause() {
        paused = !paused;
        pauseButton.setText(paused ? "▶  Resume Training" : "⏸  Pause Training");
    }

    private void updateStatus() {
        if (paused) {
            statusLabel.setText("⏸  Paused  Gen " + currentGen);
            statusLabel.setForeground(new Color(255, 180, 50));
        } else if (currentGen == 0) {
            statusLabel.setText("⏳  Running generation 1…");
            statusLabel.setForeground(new Color(100, 200, 100));
        } else {
            statusLabel.setText(String.format(
                "Gen %-4d │ Best: %,d  │ Lines: %d",
                currentGen, bestFitness, bestLines));
            statusLabel.setForeground(new Color(100, 220, 100));
        }
    }

    // Public getters used by child panels
    public NeuralNetwork getBestNet()  { return bestNet; }
    public int           getDropDelay() { return dropDelay; }
    public int           getLockDelay() { return lockDelay; }
    public boolean       isPaused()    { return paused; }

    // ── Styling helpers ──────────────────────────────────────────────────

    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Monospaced", Font.PLAIN, 11));
        l.setForeground(new Color(170, 170, 200));
        return l;
    }

    private void styleButton(JButton btn, Color bg) {
        btn.setFont(new Font("Monospaced", Font.BOLD, 11));
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(bg.brighter(), 1),
            BorderFactory.createEmptyBorder(4, 10, 4, 10)));
    }

    private static void sleep(int ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
