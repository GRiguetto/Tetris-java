import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;

/**
 * Right-hand panel showing:
 *  • Current generation / best lines / average score
 *  • Line chart of best and average fitness over all generations
 *  • NN architecture diagram
 *  • Live weight heat-map of the best network
 */
public class StatsPanel extends JPanel {

    private static final Color BG         = new Color(15, 15, 25);
    private static final Color ACCENT     = new Color(100, 180, 255);
    private static final Color GOLD       = new Color(255, 215, 0);
    private static final Color GREEN_DIM  = new Color(60, 200, 100);
    private static final Color RED_DIM    = new Color(220, 80, 80);
    private static final Color GRID_COL   = new Color(35, 35, 55);

    private final TrainingFrame frame;

    public StatsPanel(TrainingFrame frame) {
        this.frame = frame;
        setBackground(BG);
        setPreferredSize(new Dimension(370, SimBoard.ROWS * 26 + 2));
        setBorder(BorderFactory.createLineBorder(new Color(80, 80, 140), 2));
    }

    @Override
    protected void paintComponent(Graphics gx) {
        super.paintComponent(gx);
        Graphics2D g = (Graphics2D) gx;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                           RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int W = getWidth();
        int yOff = 10;

        // ── Header ───────────────────────────────────────────────────────
        g.setFont(new Font("Monospaced", Font.BOLD, 15));
        g.setColor(ACCENT);
        drawCentred(g, "🧠  Neural Network Training", W, yOff + 15);
        yOff += 35;

        // ── Key stats ────────────────────────────────────────────────────
        int gen   = frame.currentGen;
        int best  = frame.bestFitness;
        int lines = frame.bestLines;
        double avg = frame.avgFitness;
        boolean paused = frame.isPaused();

        String statusStr = paused ? "⏸ PAUSED" : "▶ TRAINING";
        Color  statusCol = paused ? new Color(255, 180, 50) : GREEN_DIM;

        yOff = drawStat(g, "Generation",   String.valueOf(gen),           ACCENT,    10, yOff, W);
        yOff = drawStat(g, "Best Lines",   String.valueOf(lines),         GOLD,      10, yOff, W);
        yOff = drawStat(g, "Best Fitness", String.format("%,d", best),    GOLD,      10, yOff, W);
        yOff = drawStat(g, "Avg Fitness",  String.format("%.0f", avg),    GREEN_DIM, 10, yOff, W);
        yOff = drawStat(g, "Status",       statusStr,                     statusCol, 10, yOff, W);
        yOff = drawStat(g, "Population",   String.valueOf(GeneticAlgorithm.POP_SIZE), ACCENT, 10, yOff, W);

        yOff += 8;
        drawDivider(g, 10, yOff, W - 20);
        yOff += 12;

        // ── Fitness Chart ────────────────────────────────────────────────
        int chartH = 130;
        int chartX = 14, chartW = W - 28;
        drawChart(g, chartX, yOff, chartW, chartH);
        yOff += chartH + 14;

        drawDivider(g, 10, yOff, W - 20);
        yOff += 12;

        // ── NN Architecture ──────────────────────────────────────────────
        int archH = 80;
        drawArchitecture(g, 14, yOff, W - 28, archH);
        yOff += archH + 10;

        drawDivider(g, 10, yOff, W - 20);
        yOff += 12;

        // ── Weight Heat Map ──────────────────────────────────────────────
        NeuralNetwork nn = frame.getBestNet();
        if (nn != null) {
            int hmH = 75;
            drawWeightHeatmap(g, 14, yOff, W - 28, hmH, nn);
            yOff += hmH + 10;
        }

        // ── Config ───────────────────────────────────────────────────────
        drawDivider(g, 10, yOff, W - 20);
        yOff += 10;
        g.setFont(new Font("Monospaced", Font.PLAIN, 10));
        g.setColor(new Color(90, 90, 120));
        String cfg = String.format(
            "Pop:%d  Elite:%d  Mut:%.0f%%  TourK:%d  MaxPieces:%d",
            GeneticAlgorithm.POP_SIZE, GeneticAlgorithm.ELITE,
            GeneticAlgorithm.MUT_RATE * 100, GeneticAlgorithm.TOURNAMENT_K,
            GeneticAlgorithm.MAX_PIECES);
        drawCentred(g, cfg, W, yOff + 11);
        yOff += 16;
        g.setColor(new Color(70, 70, 100));
        drawCentred(g, "Architecture: " + NeuralNetwork.IN + " → " +
                       NeuralNetwork.H1 + " (tanh) → " + NeuralNetwork.OUT + " (linear)", W, yOff + 11);
    }

    // ── Chart ──────────────────────────────────────────────────────────────

    private void drawChart(Graphics2D g, int x, int y, int w, int h) {
        List<Integer> bHist = frame.bestHistory;
        List<Double>  aHist = frame.avgHistory;

        // Background
        g.setColor(new Color(20, 20, 35));
        g.fillRoundRect(x, y, w, h, 8, 8);
        g.setColor(GRID_COL);
        g.drawRoundRect(x, y, w, h, 8, 8);

        // Label
        g.setFont(new Font("Monospaced", Font.BOLD, 11));
        g.setColor(new Color(140, 140, 180));
        g.drawString("Fitness over Generations", x + 6, y + 14);

        int pad = 20;
        int cX = x + pad, cY = y + 18, cW = w - pad - 4, cH = h - 26;

        // Grid lines
        g.setColor(GRID_COL);
        for (int i = 0; i <= 4; i++) {
            int gy = cY + cH - i * cH / 4;
            g.drawLine(cX, gy, cX + cW, gy);
        }

        if (bHist.size() < 2) return;

        List<Integer> bSnap;
        List<Double>  aSnap;
        synchronized (bHist) { bSnap = new ArrayList<>(bHist); }
        synchronized (aHist) { aSnap = new ArrayList<>(aHist); }
        int n = Math.min(bSnap.size(), aSnap.size());
        if (n < 2) return;

        int maxVal = bSnap.stream().mapToInt(Integer::intValue).max().orElse(1);
        if (maxVal == 0) maxVal = 1;

        // Average line
        g.setColor(new Color(60, 180, 100, 180));
        g.setStroke(new BasicStroke(1.5f));
        drawLine(g, aSnap, n, maxVal, cX, cY, cW, cH);

        // Best line
        g.setColor(GOLD);
        g.setStroke(new BasicStroke(2.2f));
        drawLineInt(g, bSnap, n, maxVal, cX, cY, cW, cH);

        g.setStroke(new BasicStroke(1f));

        // Legend
        g.setFont(new Font("Monospaced", Font.PLAIN, 9));
        g.setColor(GOLD);
        g.fillRect(x + w - 80, y + 5, 10, 6);
        g.setColor(new Color(200, 200, 200));
        g.drawString("Best", x + w - 66, y + 11);
        g.setColor(GREEN_DIM);
        g.fillRect(x + w - 80, y + 14, 10, 6);
        g.setColor(new Color(200, 200, 200));
        g.drawString("Avg", x + w - 66, y + 20);
    }

    private void drawLine(Graphics2D g, List<Double> data, int n, int maxV,
                          int cx, int cy, int cw, int ch) {
        int step = Math.max(1, n / cw);
        int prevX = -1, prevY = -1;
        for (int i = 0; i < n; i += step) {
            int px = cx + (int) ((double) i / (n - 1) * cw);
            int py = cy + ch - (int) (data.get(i) / maxV * ch);
            if (prevX >= 0) g.drawLine(prevX, prevY, px, py);
            prevX = px; prevY = py;
        }
    }

    private void drawLineInt(Graphics2D g, List<Integer> data, int n, int maxV,
                              int cx, int cy, int cw, int ch) {
        int step = Math.max(1, n / cw);
        int prevX = -1, prevY = -1;
        for (int i = 0; i < n; i += step) {
            int px = cx + (int) ((double) i / (n - 1) * cw);
            int py = cy + ch - (int) ((double) data.get(i) / maxV * ch);
            if (prevX >= 0) g.drawLine(prevX, prevY, px, py);
            prevX = px; prevY = py;
        }
    }

    // ── Architecture Diagram ───────────────────────────────────────────────

    private void drawArchitecture(Graphics2D g, int x, int y, int w, int h) {
        g.setColor(new Color(20, 20, 35));
        g.fillRoundRect(x, y, w, h, 8, 8);
        g.setColor(GRID_COL);
        g.drawRoundRect(x, y, w, h, 8, 8);

        g.setFont(new Font("Monospaced", Font.BOLD, 11));
        g.setColor(new Color(140, 140, 180));
        g.drawString("Network Architecture", x + 6, y + 14);

        int[] sizes = { NeuralNetwork.IN, NeuralNetwork.H1, NeuralNetwork.OUT };
        String[] labels = { "Input\n(8)", "Hidden\n(20)", "Output\n(1)" };
        Color[]  cols   = { new Color(80,130,230), new Color(100,200,100), new Color(230,180,50) };

        int colW = w / 3;
        int nodeR = 5;
        int yMid = y + h / 2 + 8;

        int[][] centres = new int[3][];
        for (int layer = 0; layer < 3; layer++) {
            int cx = x + layer * colW + colW / 2;
            int show = Math.min(sizes[layer], 8);
            centres[layer] = new int[]{ cx, yMid };

            // Connections to next layer (sample)
            if (layer < 2) {
                g.setColor(new Color(60, 60, 80));
                g.setStroke(new BasicStroke(0.5f));
                int nx = x + (layer + 1) * colW + colW / 2;
                for (int i = 0; i < show; i++) {
                    int fromY = yMid - (show / 2 - i) * 10;
                    int toShow = Math.min(sizes[layer + 1], 8);
                    for (int j = 0; j < toShow; j++) {
                        int toY = yMid - (toShow / 2 - j) * 10;
                        g.drawLine(cx + nodeR, fromY, nx - nodeR, toY);
                    }
                }
                g.setStroke(new BasicStroke(1f));
            }

            // Nodes
            for (int i = 0; i < show; i++) {
                int ny = yMid - (show / 2 - i) * 10;
                g.setColor(cols[layer]);
                g.fillOval(cx - nodeR, ny - nodeR, nodeR * 2, nodeR * 2);
            }
            if (sizes[layer] > 8) {
                g.setColor(cols[layer]);
                g.setFont(new Font("Monospaced", Font.PLAIN, 9));
                g.drawString("…", cx - 3, yMid + 32);
            }

            // Label
            g.setFont(new Font("Monospaced", Font.BOLD, 9));
            g.setColor(cols[layer].brighter());
            String lab = labels[layer].replace("\n", " ");
            g.drawString(lab, cx - g.getFontMetrics().stringWidth(lab) / 2, y + h - 5);
        }
    }

    // ── Weight Heat Map ────────────────────────────────────────────────────

    private void drawWeightHeatmap(Graphics2D g, int x, int y, int w, int h, NeuralNetwork nn) {
        g.setColor(new Color(20, 20, 35));
        g.fillRoundRect(x, y, w, h, 8, 8);
        g.setColor(GRID_COL);
        g.drawRoundRect(x, y, w, h, 8, 8);

        g.setFont(new Font("Monospaced", Font.BOLD, 11));
        g.setColor(new Color(140, 140, 180));
        g.drawString("Input→Hidden Weights  (W1)", x + 6, y + 14);

        // Draw w1 (IN × H1 = 8 × 20) as a colour-coded grid
        int rows = NeuralNetwork.H1;   // 20
        int cols = NeuralNetwork.IN;   // 8
        int cellW = Math.max(1, (w - 12) / cols);
        int cellH = Math.max(1, (h - 22) / rows);

        double max = 0;
        for (double v : nn.w1) max = Math.max(max, Math.abs(v));
        if (max == 0) max = 1;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                double v = nn.w1[r * cols + c] / max;  // -1..1
                Color col = v > 0
                    ? new Color(0, (int)(v * 220), 0)
                    : new Color((int)(-v * 220), 0, 0);
                g.setColor(col);
                g.fillRect(x + 6 + c * cellW, y + 18 + r * cellH, cellW, cellH);
            }
        }

        // Legend
        g.setFont(new Font("Monospaced", Font.PLAIN, 8));
        g.setColor(RED_DIM);    g.drawString("neg", x + w - 55, y + h - 3);
        g.setColor(GREEN_DIM);  g.drawString("pos", x + w - 30, y + h - 3);
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private int drawStat(Graphics2D g, String label, String value,
                          Color valueColor, int x, int y, int W) {
        int rowH = 22;
        g.setFont(new Font("Monospaced", Font.PLAIN, 12));
        g.setColor(new Color(130, 130, 160));
        g.drawString(label + ":", x, y + 14);

        g.setFont(new Font("Monospaced", Font.BOLD, 13));
        g.setColor(valueColor);
        FontMetrics fm = g.getFontMetrics();
        g.drawString(value, W - fm.stringWidth(value) - x, y + 14);
        return y + rowH;
    }

    private void drawDivider(Graphics2D g, int x, int y, int w) {
        g.setColor(new Color(50, 50, 80));
        g.setStroke(new BasicStroke(1f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                                    1f, new float[]{ 3f, 4f }, 0f));
        g.drawLine(x, y, x + w, y);
        g.setStroke(new BasicStroke(1f));
    }

    private void drawCentred(Graphics2D g, String s, int W, int y) {
        FontMetrics fm = g.getFontMetrics();
        g.drawString(s, (W - fm.stringWidth(s)) / 2, y);
    }
}
