/**
 * Lightweight headless Tetris board used for AI training simulation.
 * No Swing/AWT dependencies – pure logic for maximum speed.
 *
 * Features extracted (8 inputs for the Neural Network):
 *  0. Aggregate height / (ROWS*COLS)
 *  1. Complete lines / 4
 *  2. Holes / (ROWS*COLS)
 *  3. Bumpiness / (ROWS*COLS)
 *  4. Max column height / ROWS
 *  5. Min column height / ROWS
 *  6. Wells / (ROWS*COLS)
 *  7. Height std-deviation / ROWS
 */
public class SimBoard {

    public static final int COLS = 10;
    public static final int ROWS = 20;

    boolean[][] g;   // g[row][col] = true if filled

    public SimBoard() {
        g = new boolean[ROWS][COLS];
    }

    /** Copy constructor (for fast cloning during move search). */
    public SimBoard(SimBoard o) {
        g = new boolean[ROWS][COLS];
        for (int r = 0; r < ROWS; r++) g[r] = o.g[r].clone();
    }

    // ── Piece placement ──────────────────────────────────────────────────────

    /** True if shape can be placed at (px, py) without collision. */
    public boolean fits(int[][] shape, int px, int py) {
        for (int r = 0; r < shape.length; r++)
            for (int c = 0; c < shape[r].length; c++) {
                if (shape[r][c] == 0) continue;
                int nr = py + r, nc = px + c;
                if (nc < 0 || nc >= COLS || nr >= ROWS) return false;
                if (nr >= 0 && g[nr][nc]) return false;
            }
        return true;
    }

    /** Drop the piece from the top and return the final Y it lands at. */
    public int dropY(int[][] shape, int px) {
        int py = 0;
        while (fits(shape, px, py + 1)) py++;
        return py;
    }

    /** True if the piece can start falling from the top at column px. */
    public boolean canStart(int[][] shape, int px) {
        return fits(shape, px, 0) || fits(shape, px, -1);
    }

    /** Place the piece permanently on the board. */
    public void place(int[][] shape, int px, int py) {
        for (int r = 0; r < shape.length; r++)
            for (int c = 0; c < shape[r].length; c++) {
                if (shape[r][c] == 0) continue;
                int nr = py + r, nc = px + c;
                if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS)
                    g[nr][nc] = true;
            }
    }

    /** Clear full lines and return how many were cleared. */
    public int clearLines() {
        int n = 0;
        for (int r = ROWS - 1; r >= 0; r--) {
            if (rowFull(r)) { shiftDown(r); r++; n++; }
        }
        return n;
    }

    boolean rowFull(int r) {
        for (int c = 0; c < COLS; c++) if (!g[r][c]) return false;
        return true;
    }

    void shiftDown(int row) {
        for (int r = row; r > 0; r--) g[r] = g[r - 1].clone();
        g[0] = new boolean[COLS];
    }

    /** True if any cell in row 0 is filled (game over condition). */
    public boolean gameOver() {
        for (int c = 0; c < COLS; c++) if (g[0][c]) return true;
        return false;
    }

    public boolean get(int r, int c) { return g[r][c]; }

    // ── Feature Extraction ───────────────────────────────────────────────────

    /** Return the 8 normalised features used as NN inputs. */
    public double[] features() {
        int[] h = columnHeights();

        int aggH = 0, maxH = 0, minH = ROWS;
        for (int v : h) { aggH += v; if (v > maxH) maxH = v; if (v < minH) minH = v; }

        int holes = countHoles();
        int bumpy = bumpiness(h);
        int wells = countWells(h);
        int lines = countCompleteLines();

        double mean = aggH / (double) COLS;
        double variance = 0;
        for (int v : h) variance += (v - mean) * (v - mean);
        variance /= COLS;

        double N = ROWS * COLS;
        return new double[]{
            aggH   / N,
            lines  / 4.0,
            holes  / N,
            bumpy  / N,
            maxH   / (double) ROWS,
            minH   / (double) ROWS,
            wells  / N,
            Math.sqrt(variance) / ROWS
        };
    }

    int[] columnHeights() {
        int[] h = new int[COLS];
        for (int c = 0; c < COLS; c++)
            for (int r = 0; r < ROWS; r++)
                if (g[r][c]) { h[c] = ROWS - r; break; }
        return h;
    }

    int countHoles() {
        int holes = 0;
        for (int c = 0; c < COLS; c++) {
            boolean topped = false;
            for (int r = 0; r < ROWS; r++) {
                if (g[r][c]) topped = true;
                else if (topped) holes++;
            }
        }
        return holes;
    }

    int bumpiness(int[] h) {
        int b = 0;
        for (int c = 0; c < COLS - 1; c++) b += Math.abs(h[c] - h[c + 1]);
        return b;
    }

    int countWells(int[] h) {
        int w = 0;
        for (int c = 0; c < COLS; c++) {
            int lh = (c > 0)      ? h[c - 1] : ROWS;
            int rh = (c < COLS-1) ? h[c + 1] : ROWS;
            int depth = Math.min(lh, rh) - h[c];
            if (depth > 0) w += depth;
        }
        return w;
    }

    int countCompleteLines() {
        int n = 0;
        for (int r = 0; r < ROWS; r++) if (rowFull(r)) n++;
        return n;
    }
}
