import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 * Renders a live Tetris game being played by the best Neural Network found so far.
 * When a game ends it automatically restarts.
 * Speed is controlled via the parent TrainingFrame.
 */
public class TetrisDisplay extends JPanel {

    private static final int CELL  = 26;
    private static final int W     = SimBoard.COLS * CELL;
    private static final int H     = SimBoard.ROWS * CELL;

    // Piece colours mirroring the original game
    private static final Color[] PIECE_COLORS = {
        new Color(0, 240, 240),   // I
        new Color(240, 240, 0),   // O
        new Color(160, 0, 240),   // T
        new Color(0, 240, 0),     // S
        new Color(240, 0, 0),     // Z
        new Color(0, 0, 240),     // J
        new Color(240, 160, 0)    // L
    };

    private final TrainingFrame frame;

    // Game state (updated by demo thread)
    private SimBoard  board;
    private int       currentType  = 0;
    private int       currentRot   = 0;
    private int       currentX     = 0;
    private int       currentY     = 0;
    private int       ghostY       = 0;
    private int       pieces       = 0;
    private int       linesCleared = 0;
    private int       score        = 0;
    private boolean   gameOver     = false;

    private volatile Thread demoThread;

    public TetrisDisplay(TrainingFrame frame) {
        this.frame = frame;
        setPreferredSize(new Dimension(W + 2, H + 2));
        setBackground(new Color(10, 10, 20));
        setBorder(BorderFactory.createLineBorder(new Color(80, 80, 140), 2));
    }

    /** Start / restart the demo loop. */
    public void startDemo() {
        if (demoThread != null) demoThread.interrupt();
        demoThread = new Thread(this::demoLoop, "demo-thread");
        demoThread.setDaemon(true);
        demoThread.start();
    }

    private void demoLoop() {
        Random rng = new Random();
        while (!Thread.currentThread().isInterrupted()) {
            // Wait until a trained network is available
            NeuralNetwork nn = frame.getBestNet();
            if (nn == null) {
                try { Thread.sleep(300); } catch (InterruptedException e) { return; }
                continue;
            }

            // --- New game ---
            board       = new SimBoard();
            linesCleared = 0;
            score        = 0;
            pieces       = 0;
            gameOver     = false;

            while (!gameOver) {
                NeuralNetwork current = frame.getBestNet();  // may update each piece
                if (current == null) current = nn;

                int type = rng.nextInt(7);
                currentType = type;

                TetrisSimulator.Move move = TetrisSimulator.bestMove(current, board, type);

                if (move == null) { gameOver = true; break; }

                // Animate the piece falling
                int[][] shape = Tetromino.SHAPES[type][move.rot];
                currentRot = move.rot;
                currentX   = move.x;
                currentY   = 0;

                // Calculate ghost
                ghostY = board.dropY(shape, move.x);

                // Animate drop
                while (currentY < move.dropY) {
                    currentY++;
                    SwingUtilities.invokeLater(this::repaint);
                    try {
                        Thread.sleep(Math.max(5, frame.getDropDelay()));
                    } catch (InterruptedException e) { return; }
                }

                // Lock piece
                board.place(shape, move.x, move.dropY);
                int cleared = board.clearLines();
                linesCleared += cleared;
                score        += cleared * cleared * 100;
                pieces++;

                if (board.gameOver()) gameOver = true;

                SwingUtilities.invokeLater(this::repaint);
                try {
                    Thread.sleep(Math.max(10, frame.getLockDelay()));
                } catch (InterruptedException e) { return; }
            }

            // Show game-over briefly, then restart
            SwingUtilities.invokeLater(this::repaint);
            try { Thread.sleep(1500); } catch (InterruptedException e) { return; }
        }
    }

    // ── Rendering ─────────────────────────────────────────────────────────

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (board == null) {
            drawWaiting(g);
            return;
        }
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Grid lines
        g2.setColor(new Color(25, 25, 45));
        for (int r = 0; r <= SimBoard.ROWS; r++)
            g2.drawLine(0, r * CELL, W, r * CELL);
        for (int c = 0; c <= SimBoard.COLS; c++)
            g2.drawLine(c * CELL, 0, c * CELL, H);

        // Placed cells
        for (int r = 0; r < SimBoard.ROWS; r++)
            for (int c = 0; c < SimBoard.COLS; c++)
                if (board.get(r, c))
                    drawCell(g2, c * CELL, r * CELL, new Color(80, 120, 200), false);

        // Ghost piece
        if (!gameOver) {
            int[][] shape = Tetromino.SHAPES[currentType][currentRot];
            Color pc = PIECE_COLORS[currentType];
            for (int r = 0; r < shape.length; r++)
                for (int c = 0; c < shape[r].length; c++) {
                    if (shape[r][c] == 0) continue;
                    int px = (currentX + c) * CELL;
                    int py = (ghostY  + r) * CELL;
                    g2.setColor(new Color(pc.getRed(), pc.getGreen(), pc.getBlue(), 50));
                    g2.fillRect(px + 1, py + 1, CELL - 2, CELL - 2);
                    g2.setColor(new Color(pc.getRed(), pc.getGreen(), pc.getBlue(), 100));
                    g2.drawRect(px + 1, py + 1, CELL - 2, CELL - 2);
                }

            // Active piece
            for (int r = 0; r < shape.length; r++)
                for (int c = 0; c < shape[r].length; c++) {
                    if (shape[r][c] == 0) continue;
                    int px = (currentX + c) * CELL;
                    int py = (currentY + r) * CELL;
                    if (py >= 0) drawCell(g2, px, py, pc, false);
                }
        }

        // Game-over overlay
        if (gameOver) {
            g2.setColor(new Color(0, 0, 0, 160));
            g2.fillRect(0, 0, W, H);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Monospaced", Font.BOLD, 20));
            drawCentred(g2, "GAME OVER", H / 2 - 20);
            g2.setFont(new Font("Monospaced", Font.PLAIN, 12));
            g2.setColor(new Color(200, 200, 200));
            drawCentred(g2, "Lines: " + linesCleared + "  Pieces: " + pieces, H / 2 + 10);
            drawCentred(g2, "Restarting...", H / 2 + 30);
        }

        // HUD (top right corner)
        g2.setFont(new Font("Monospaced", Font.BOLD, 11));
        g2.setColor(new Color(180, 180, 255));
        g2.drawString("Lines: " + linesCleared, 5, 15);
        g2.drawString("Pieces: " + pieces, 5, 30);
    }

    private void drawCell(Graphics2D g2, int x, int y, Color c, boolean ghost) {
        g2.setColor(c);
        g2.fillRect(x + 1, y + 1, CELL - 2, CELL - 2);
        g2.setColor(c.brighter());
        g2.drawLine(x + 1, y + 1, x + CELL - 2, y + 1);
        g2.drawLine(x + 1, y + 1, x + 1,         y + CELL - 2);
        g2.setColor(c.darker());
        g2.drawLine(x + 1,         y + CELL - 2, x + CELL - 2, y + CELL - 2);
        g2.drawLine(x + CELL - 2, y + 1,          x + CELL - 2, y + CELL - 2);
    }

    private void drawCentred(Graphics2D g2, String s, int y) {
        FontMetrics fm = g2.getFontMetrics();
        g2.drawString(s, (W - fm.stringWidth(s)) / 2, y);
    }

    private void drawWaiting(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(new Color(100, 100, 140));
        g2.setFont(new Font("Monospaced", Font.BOLD, 14));
        drawCentred(g2, "Initialising...", H / 2);
        g2.setFont(new Font("Monospaced", Font.PLAIN, 11));
        drawCentred(g2, "Training generation 1", H / 2 + 20);
    }
}
