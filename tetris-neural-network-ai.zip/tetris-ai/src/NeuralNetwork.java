import java.util.Random;

/**
 * Feedforward Neural Network: 8 inputs -> 20 hidden (tanh) -> 1 output (linear)
 * Used to evaluate Tetris board states.
 */
public class NeuralNetwork {

    public static final int IN   = 8;
    public static final int H1   = 20;
    public static final int OUT  = 1;
    public static final int GENOME_SIZE = IN * H1 + H1 + H1 * OUT + OUT; // 181

    // Weights stored as flat arrays for easy genetic manipulation
    public double[] w1 = new double[IN * H1];   // input -> hidden
    public double[] b1 = new double[H1];          // hidden biases
    public double[] w2 = new double[H1 * OUT];    // hidden -> output
    public double[] b2 = new double[OUT];          // output biases

    /** Evaluate board features and return a score for this board state. */
    public double forward(double[] x) {
        double[] h = new double[H1];
        for (int j = 0; j < H1; j++) {
            double s = b1[j];
            for (int i = 0; i < IN; i++) s += x[i] * w1[j * IN + i];
            h[j] = Math.tanh(s);  // tanh activation
        }
        double out = b2[0];
        for (int j = 0; j < H1; j++) out += h[j] * w2[j];
        return out;  // linear output = board score
    }

    /** Flatten all weights into a single array (genome). */
    public double[] getWeights() {
        double[] g = new double[GENOME_SIZE];
        int k = 0;
        for (double v : w1) g[k++] = v;
        for (double v : b1) g[k++] = v;
        for (double v : w2) g[k++] = v;
        for (double v : b2) g[k++] = v;
        return g;
    }

    /** Load weights from a flat genome array. */
    public void setWeights(double[] g) {
        int k = 0;
        for (int i = 0; i < w1.length; i++) w1[i] = g[k++];
        for (int i = 0; i < b1.length; i++) b1[i] = g[k++];
        for (int i = 0; i < w2.length; i++) w2[i] = g[k++];
        for (int i = 0; i < b2.length; i++) b2[i] = g[k++];
    }

    /** Initialize with He initialization (good for tanh). */
    public void randomize(Random rng) {
        double scaleIn  = Math.sqrt(2.0 / IN);
        double scaleH1  = Math.sqrt(2.0 / H1);
        for (int i = 0; i < w1.length; i++) w1[i] = rng.nextGaussian() * scaleIn;
        for (int i = 0; i < b1.length; i++) b1[i] = 0;
        for (int i = 0; i < w2.length; i++) w2[i] = rng.nextGaussian() * scaleH1;
        b2[0] = 0;
    }

    /** Deep copy. */
    public NeuralNetwork copy() {
        NeuralNetwork n = new NeuralNetwork();
        n.setWeights(this.getWeights());
        return n;
    }
}
