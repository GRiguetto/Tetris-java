import java.util.*;
import java.util.concurrent.*;

/**
 * Genetic Algorithm that evolves Neural Network weights to play Tetris.
 *
 * Each "genome" is a flat array of NN weights.
 * Fitness = lines_cleared × 1000 + pieces_placed  (higher = better)
 *
 * Pipeline each generation:
 *   1. Evaluate all genomes in parallel (multi-threaded)
 *   2. Keep top ELITE genomes unchanged
 *   3. Fill rest via tournament-selection + crossover + Gaussian mutation
 */
public class GeneticAlgorithm {

    // ── Hyper-parameters ────────────────────────────────────────────────────
    public static final int  POP_SIZE      = 200;   // population size
    public static final int  ELITE         = 10;    // elites kept per gen
    public static final int  TOURNAMENT_K  = 7;     // tournament size
    public static final int  MAX_PIECES    = 600;   // pieces per game evaluation
    public static final double MUT_RATE    = 0.12;  // per-weight mutation probability
    public static final double MUT_STD     = 0.25;  // mutation magnitude (std-dev)
    // ────────────────────────────────────────────────────────────────────────

    /** Called after every generation with updated statistics. */
    public interface Listener {
        void onGeneration(int gen, int bestFitness, double avgFitness,
                          int bestLines, NeuralNetwork bestNet);
    }

    private NeuralNetwork[] pop;
    private int[]    fitness;
    private Integer[] sorted;   // indices sorted descending by fitness

    public int    generation  = 0;
    public int    bestFitness = 0;
    public double avgFitness  = 0;
    public int    bestLines   = 0;
    public NeuralNetwork bestNet;

    private final Random rng = new Random();
    private final List<Listener> listeners = new ArrayList<>();

    public GeneticAlgorithm() {
        pop     = new NeuralNetwork[POP_SIZE];
        fitness = new int[POP_SIZE];
        sorted  = new Integer[POP_SIZE];

        for (int i = 0; i < POP_SIZE; i++) {
            pop[i] = new NeuralNetwork();
            pop[i].randomize(rng);
            sorted[i] = i;
        }
    }

    public void addListener(Listener l) { listeners.add(l); }

    // ── Public API ───────────────────────────────────────────────────────────

    /**
     * Evaluate the current generation and produce the next one.
     * Blocking – call from a background thread.
     */
    public void evolve() throws InterruptedException {
        long seed = System.nanoTime();           // same piece sequence for all
        evaluateAll(seed);
        sortByFitness();
        computeStats(seed);
        buildNextGeneration();
        generation++;
        notifyListeners();
    }

    // ── Evaluation ───────────────────────────────────────────────────────────

    private void evaluateAll(long seed) throws InterruptedException {
        int threads = Math.max(1, Runtime.getRuntime().availableProcessors());
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch latch = new CountDownLatch(POP_SIZE);

        for (int i = 0; i < POP_SIZE; i++) {
            final int idx = i;
            pool.submit(() -> {
                fitness[idx] = TetrisSimulator.simulate(pop[idx], seed, MAX_PIECES);
                latch.countDown();
            });
        }
        latch.await();
        pool.shutdown();
    }

    private void sortByFitness() {
        for (int i = 0; i < POP_SIZE; i++) sorted[i] = i;
        Arrays.sort(sorted, (a, b) -> fitness[b] - fitness[a]);
    }

    private void computeStats(long seed) {
        bestFitness = fitness[sorted[0]];
        bestNet     = pop[sorted[0]].copy();
        bestLines   = bestFitness / 1000;

        long sum = 0;
        for (int f : fitness) sum += f;
        avgFitness = sum / (double) POP_SIZE;
    }

    // ── Next Generation ──────────────────────────────────────────────────────

    private void buildNextGeneration() {
        NeuralNetwork[] next = new NeuralNetwork[POP_SIZE];

        // 1. Elitism – keep top ELITE unchanged
        for (int i = 0; i < ELITE; i++)
            next[i] = pop[sorted[i]].copy();

        // 2. Rest: crossover + mutation
        for (int i = ELITE; i < POP_SIZE; i++) {
            NeuralNetwork pA = tournament();
            NeuralNetwork pB = tournament();
            next[i] = crossover(pA, pB);
            mutate(next[i]);
        }

        pop = next;
    }

    /** Tournament selection: pick k random individuals, return fittest. */
    private NeuralNetwork tournament() {
        int best = -1, bestF = -1;
        for (int i = 0; i < TOURNAMENT_K; i++) {
            int idx = sorted[rng.nextInt(POP_SIZE)];
            if (fitness[idx] > bestF) { bestF = fitness[idx]; best = idx; }
        }
        return pop[best];
    }

    /** Uniform crossover: each weight randomly from parent A or B. */
    private NeuralNetwork crossover(NeuralNetwork a, NeuralNetwork b) {
        double[] wa = a.getWeights();
        double[] wb = b.getWeights();
        double[] wc = new double[wa.length];
        for (int i = 0; i < wa.length; i++)
            wc[i] = rng.nextBoolean() ? wa[i] : wb[i];
        NeuralNetwork child = new NeuralNetwork();
        child.setWeights(wc);
        return child;
    }

    /** Gaussian perturbation of each weight with probability MUT_RATE. */
    private void mutate(NeuralNetwork nn) {
        double[] w = nn.getWeights();
        for (int i = 0; i < w.length; i++)
            if (rng.nextDouble() < MUT_RATE)
                w[i] += rng.nextGaussian() * MUT_STD;
        nn.setWeights(w);
    }

    private void notifyListeners() {
        for (Listener l : listeners)
            l.onGeneration(generation, bestFitness, avgFitness, bestLines, bestNet);
    }

    // ── Accessors ────────────────────────────────────────────────────────────
    public NeuralNetwork getBest() { return bestNet; }
    public int           getGeneration() { return generation; }
}
