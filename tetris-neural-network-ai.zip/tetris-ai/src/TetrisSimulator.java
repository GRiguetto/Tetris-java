import java.util.Random;

/**
 * Headless Tetris game engine for AI training.
 *
 * Strategy: for every incoming piece, enumerate ALL valid placements
 * (rotation × column), simulate each, score the resulting board with
 * the Neural Network, and pick the highest-scoring placement.
 */
public class TetrisSimulator {

    /** A candidate move: rotation index + column. */
    public static class Move {
        public final int rot, x, dropY;
        public final double score;
        Move(int rot, int x, int dropY, double score) {
            this.rot = rot; this.x = x; this.dropY = dropY; this.score = score;
        }
    }

    /**
     * Simulate a full game and return a fitness value.
     *
     * fitness = linesCleared * 1000 + piecesPlaced
     *
     * Using a fixed seed ensures all genomes in one generation
     * face the same piece sequence – fair comparison.
     */
    public static int simulate(NeuralNetwork nn, long seed, int maxPieces) {
        SimBoard board = new SimBoard();
        Random rng = new Random(seed);
        int totalLines = 0, pieces = 0;

        while (pieces < maxPieces) {
            int type = rng.nextInt(7);
            Move best = bestMove(nn, board, type);
            if (best == null) break;   // no valid placement → game over

            int[][] shape = Tetromino.SHAPES[type][best.rot];
            board.place(shape, best.x, best.dropY);
            totalLines += board.clearLines();
            pieces++;

            if (board.gameOver()) break;
        }

        return totalLines * 1000 + pieces;
    }

    /**
     * Find the best (rotation, column) placement for the given piece type
     * on the given board state.
     * Returns null if no valid placement exists (board is too full).
     */
    public static Move bestMove(NeuralNetwork nn, SimBoard board, int type) {
        double best = Double.NEGATIVE_INFINITY;
        Move bestMove = null;

        int numRots = Tetromino.SHAPES[type].length;

        for (int rot = 0; rot < numRots; rot++) {
            int[][] shape = Tetromino.SHAPES[type][rot];
            int pieceW = shape[0].length;

            for (int x = 0; x <= SimBoard.COLS - pieceW; x++) {
                // Check piece can reach this column
                if (!board.fits(shape, x, 0) && !board.fits(shape, x, -1)) continue;

                SimBoard copy = new SimBoard(board);
                int py = copy.dropY(shape, x);
                copy.place(shape, x, py);

                // Penalise moves that immediately fill row 0
                if (copy.gameOver()) continue;

                copy.clearLines();

                double score = nn.forward(copy.features());

                if (score > best) {
                    best = score;
                    bestMove = new Move(rot, x, py, score);
                }
            }
        }
        return bestMove;
    }

    /**
     * Play one piece and return the resulting board state.
     * Used by the live demo panel to advance the game step-by-step.
     *
     * @return { rot, x, dropY, linesCleared } or null if game over
     */
    public static int[] applyBestMove(NeuralNetwork nn, SimBoard board, int type) {
        Move m = bestMove(nn, board, type);
        if (m == null) return null;

        int[][] shape = Tetromino.SHAPES[type][m.rot];
        board.place(shape, m.x, m.dropY);
        int cleared = board.clearLines();

        return new int[]{ m.rot, m.x, m.dropY, cleared };
    }
}
