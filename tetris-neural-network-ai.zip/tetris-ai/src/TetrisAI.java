import javax.swing.*;

/**
 * ═══════════════════════════════════════════════════════════════════
 *  Tetris Neural Network — Genetic Algorithm Trainer
 * ═══════════════════════════════════════════════════════════════════
 *
 *  How it works:
 *  ─────────────
 *  1. A population of 200 Neural Networks (NNs) is randomly initialised.
 *
 *  2. Each NN plays a simulated Tetris game (up to 600 pieces):
 *       • For every incoming piece, ALL valid (rotation × column) placements
 *         are evaluated.
 *       • The resulting board state is encoded as 8 hand-crafted features
 *         (aggregate height, holes, bumpiness, lines, etc.).
 *       • The NN scores each candidate board; the highest-scoring placement
 *         is executed.
 *
 *  3. Fitness = lines_cleared × 1000 + pieces_placed
 *
 *  4. The Genetic Algorithm breeds the next generation:
 *       • Top 10 (elites) survive unchanged.
 *       • Remaining 190 are created via tournament selection, uniform
 *         crossover, and Gaussian weight mutation.
 *
 *  5. This repeats indefinitely; the live display shows the current
 *     best network playing in real-time.
 *
 *  Files
 *  ─────
 *   NeuralNetwork.java   – feedforward NN  (8→20→1, tanh/linear)
 *   SimBoard.java        – headless board + feature extraction
 *   TetrisSimulator.java – move search (exhaustive placement search)
 *   GeneticAlgorithm.java– GA with multi-threaded evaluation
 *   TetrisDisplay.java   – live animated game panel
 *   StatsPanel.java      – charts, heat-map, architecture diagram
 *   TrainingFrame.java   – main Swing frame
 *   TetrisAI.java        – entry point  ← you are here
 *
 *  Run:
 *    javac src/*.java -d out && java -cp out TetrisAI
 */
public class TetrisAI {
    public static void main(String[] args) {
        // Enable hardware acceleration hints
        System.setProperty("sun.java2d.opengl", "true");

        SwingUtilities.invokeLater(() -> {
            // Set a dark look-and-feel
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}

            new TrainingFrame();
        });
    }
}
