#!/bin/bash
# ─────────────────────────────────────────────────────────────────────
#  Tetris Neural Network AI — Build & Run
# ─────────────────────────────────────────────────────────────────────

set -e

SRC_DIR="$(dirname "$0")/src"
OUT_DIR="$(dirname "$0")/out"

mkdir -p "$OUT_DIR"

echo "🔨 Compiling..."
javac -encoding UTF-8 "$SRC_DIR"/*.java -d "$OUT_DIR"

echo "✅ Build OK"
echo ""
echo "🧠 Starting Tetris AI Trainer..."
echo "   - Training uses all CPU cores in parallel"
echo "   - Close the window to stop"
echo ""

java -cp "$OUT_DIR" \
     -Dsun.java2d.opengl=true \
     TetrisAI
