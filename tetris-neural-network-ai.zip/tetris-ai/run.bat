@echo off
:: ─────────────────────────────────────────────────────────────────────
::  Tetris Neural Network AI — Build & Run (Windows)
:: ─────────────────────────────────────────────────────────────────────

set SRC=%~dp0src
set OUT=%~dp0out

if not exist "%OUT%" mkdir "%OUT%"

echo Compilando...
javac -encoding UTF-8 "%SRC%\*.java" -d "%OUT%"
if errorlevel 1 (
    echo ERRO: Falha na compilacao. Verifique se o JDK esta instalado.
    pause
    exit /b 1
)

echo Build OK!
echo.
echo Iniciando Tetris AI Trainer...
echo.

java -cp "%OUT%" -Dsun.java2d.opengl=true TetrisAI
pause
